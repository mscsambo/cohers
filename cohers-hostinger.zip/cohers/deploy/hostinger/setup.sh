#!/bin/bash
# =============================================================================
#  COHERS installer / updater for Hostinger (hPanel) web & cloud hosting.
#
#  With SSH (Premium plan and up):
#      bash ~/domains/YOUR-DOMAIN/cohers/deploy/hostinger/setup.sh
#    First run asks for the domain, database and admin e-mail and writes .env.
#
#  Without SSH (Single plan): fill in .env yourself in File Manager, then run once
#  from a cron job (see DEPLOY-HOSTINGER.md):
#      bash /home/uXXXX/domains/YOUR-DOMAIN/cohers/deploy/hostinger/setup.sh --yes
#
#  Every run: creates/updates the tables, sets up the first accounts on an empty database,
#  copies the public files into the website folder, refreshes caches, sets the Telegram
#  webhook. It keeps .env, the database and photos, and never deletes anything: an existing
#  website folder that is not COHERS is renamed, not removed.
# =============================================================================
set -euo pipefail

YES=0; [[ "${1:-}" == "--yes" || "${1:-}" == "-y" ]] && YES=1
APP="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$APP"
export HOME="${HOME:-$(cd ~ && pwd)}"

say()  { printf '==> %s\n' "$*"; }
warn() { printf '!!  %s\n' "$*"; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
ask()  { # ask VAR "Question" "default"   (in --yes mode the default is taken)
    local reply=""
    [[ $YES == 1 ]] || { read -r -p "$2${3:+ [$3]}: " reply || true; }
    printf -v "$1" '%s' "${reply:-${3:-}}"
}
ask_secret() { local reply=""; read -r -s -p "$2: " reply || true; echo; printf -v "$1" '%s' "$reply"; }
envval() { grep -E "^$1=" .env 2>/dev/null | tail -1 | cut -d= -f2- | sed -E 's/^"(.*)"$/\1/'; }

# --- PHP (8.2+; hPanel → Advanced → PHP Configuration sets the version) ----------------
NEED_EXT='["pdo_mysql","mbstring","openssl","curl","fileinfo","tokenizer","ctype","dom","xml","json"]'
php_ok() {
    command -v "$1" >/dev/null 2>&1 || [[ -x "$1" ]] || return 1
    "$1" -r '$m=array_diff('"$NEED_EXT"', array_map("strtolower", get_loaded_extensions()));
             exit(version_compare(PHP_VERSION, "8.2.0", ">=") && !$m ? 0 : 1);' >/dev/null 2>&1
}
PHP=""
for c in "${PHP_BIN:-}" php /usr/bin/php /opt/alt/php84/usr/bin/php /opt/alt/php83/usr/bin/php /opt/alt/php82/usr/bin/php; do
    [[ -n "$c" ]] && php_ok "$c" && { PHP="$(command -v "$c" || echo "$c")"; break; }
done
if [[ -z "$PHP" ]]; then
    warn "Found: $(php -v 2>/dev/null | head -1 || echo 'no php in PATH')"
    die "PHP 8.2+ with pdo_mysql, mbstring, openssl, curl, fileinfo, dom, xml is needed. Set PHP 8.3 in hPanel (Advanced → PHP Configuration) and run this again."
fi
say "PHP $("$PHP" -r 'echo PHP_VERSION;') ($PHP) · app folder $APP"
artisan() { "$PHP" "$APP/artisan" "$@"; }

[[ -f vendor/autoload.php ]] || die "vendor/ is missing. Upload cohers-hostinger.zip (it includes vendor/), not the source code."
rm -f bootstrap/cache/packages.php bootstrap/cache/services.php bootstrap/cache/config.php   # never reuse caches from another machine
mkdir -p storage/app/private storage/app/public storage/framework/{cache/data,sessions,views} storage/logs bootstrap/cache
chmod -R u+rwX,go-w storage bootstrap/cache

# --- .env ------------------------------------------------------------------------------
if [[ ! -f .env ]]; then
    [[ $YES == 1 ]] && die "No .env yet. Copy deploy/hostinger/.env.hostinger to $APP/.env, fill in APP_URL and DB_*, then run again."
    say "First install — answers go into $APP/.env"
    guess="$(basename "$(dirname "$APP")")"; [[ "$guess" == *.* ]] || guess=""
    ask DOMAIN   "Domain or subdomain for COHERS (e.g. cohers.example.org)" "$guess"
    DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN%%/*}"
    [[ -n "$DOMAIN" ]] || die "A domain is needed."
    echo "  Database: hPanel → Databases → Management (create one first if you have not)."
    ask DB_NAME  "  Database name (e.g. u123456789_cohers)" ""
    ask DB_USER  "  Database user" "$DB_NAME"
    ask_secret DB_PASS "  Database password"
    ask ADMIN    "Your administrator sign-in e-mail" ""
    ask DEMO     "Load demo data? (y = demo, n = clean pilot)" "n"
    ask TG_TOKEN "Telegram bot token (Enter to skip; can be added later in Admin → Configuration)" ""
    ask TG_USER  "Telegram bot username" "cohers_bot"
    ask GEMINI   "Gemini API key (Enter for offline keyword triage)" ""

    cp deploy/hostinger/.env.hostinger .env
    "$PHP" deploy/hostinger/write-env.php .env "APP_URL=https://$DOMAIN" "DB_DATABASE=$DB_NAME" "DB_USERNAME=$DB_USER" \
        "DB_PASSWORD=$DB_PASS" "TELEGRAM_BOT_TOKEN=$TG_TOKEN" "TELEGRAM_BOT_USERNAME=${TG_USER#@}" \
        "GEMINI_API_KEY=$GEMINI" "SETUP_ADMIN_EMAIL=$ADMIN" "SETUP_DEMO=$DEMO"
    [[ -n "$GEMINI" ]] && "$PHP" deploy/hostinger/write-env.php .env COHERS_AI_DRIVER=gemini
fi
chmod 600 .env
"$PHP" deploy/hostinger/write-env.php --if-empty .env TELEGRAM_WEBHOOK_SECRET=@random
[[ -n "$(envval APP_KEY)" ]] || artisan key:generate --force --no-interaction
grep -qE '^[A-Z_]+=.*⟨' .env && die "Some values in $APP/.env still have ⟨…⟩ placeholders. Fill them in and run again."
DOMAIN="$(envval APP_URL | sed -E 's#^https?://([^/]+).*#\1#')"
[[ "$(envval APP_URL)" == https://* ]] || warn "APP_URL should start with https:// (Telegram needs it)."

# --- database ----------------------------------------------------------------------------
artisan config:clear >/dev/null
artisan db:show >/dev/null 2>&1 || die "Cannot connect to the database. Check DB_* in $APP/.env against hPanel → Databases → Management."
artisan migrate --force --no-interaction

SETUP_ARGS=()
[[ "$(envval SETUP_DEMO | tr 'A-Z' 'a-z')" == y* ]] && SETUP_ARGS+=(--demo)
[[ -n "$(envval SETUP_ADMIN_EMAIL)" ]] && SETUP_ARGS+=(--admin-email="$(envval SETUP_ADMIN_EMAIL)")
# Only acts on an empty database (prints the new passwords once); otherwise does nothing.
artisan cohers:first-run "${SETUP_ARGS[@]}" --no-interaction

# --- website folder -------------------------------------------------------------------------
# Two layouts are supported:
#  A. "beside": the app sits NEXT TO the website folder (domains/X/cohers + domains/X/public_html).
#     The public files are copied in and index.php points at the app. Safest.
#  B. "inside": the app sits INSIDE the website folder (e.g. public_html/app/). Two .htaccess files
#     send every request to app/public and refuse everything else under app/ (.env, storage, vendor).
# Symlinks are off by default on Hostinger web/cloud plans, so neither layout uses them.
if [[ -f "$APP/.docroot" ]]; then
    DOCROOT_DEFAULT="$(cat "$APP/.docroot")"
elif [[ -d "$(dirname "$APP")/public_html" ]]; then
    DOCROOT_DEFAULT="$(dirname "$APP")/public_html"
else
    DOCROOT_DEFAULT="$(dirname "$APP")"
fi
ask DOCROOT "Website folder of $DOMAIN (File Manager shows it)" "${DOCROOT:-$DOCROOT_DEFAULT}"
DOCROOT="${DOCROOT%/}"
[[ "$DOCROOT" == "$APP" ]] && die "The website folder cannot be the app folder itself. Put the app in a subfolder (e.g. public_html/app) or next to public_html."
case "$DOCROOT" in "$APP"/*) die "The website folder must not be inside the app folder.";; esac
mkdir -p "$DOCROOT"
# Hostinger's placeholder page can win over index.php, so it is set aside (not deleted).
[[ -f "$DOCROOT/default.php" ]] && mv "$DOCROOT/default.php" "$DOCROOT/default.php.disabled"

if [[ "$APP" == "$DOCROOT"/* ]]; then
    # ---- layout B: app inside the website folder ----
    REL="${APP#"$DOCROOT"/}"
    [[ "$REL" =~ ^[A-Za-z0-9._/-]+$ ]] || die "Use only letters, numbers, . _ - in the app folder name ($REL)."
    if [[ -f "$DOCROOT/.htaccess" ]] && ! grep -q 'COHERS-ROOT' "$DOCROOT/.htaccess"; then
        cp "$DOCROOT/.htaccess" "$DOCROOT/.htaccess.before-cohers-$(date +%Y%m%d-%H%M%S)"
        warn "Existing $DOCROOT/.htaccess saved as .htaccess.before-cohers-…"
    fi
    if [[ -f "$DOCROOT/index.php" || -f "$DOCROOT/index.html" ]]; then
        warn "$DOCROOT has its own index file; the .htaccess below sends every request to COHERS anyway."
    fi
    cat > "$DOCROOT/.htaccess" <<HT
# COHERS-ROOT — written by deploy/hostinger/setup.sh (re-written on every run).
# The app lives in $REL/. Only $REL/public is served; everything is routed there.
Options -Indexes
DirectoryIndex index.php
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)\$ $REL/public/\$1 [L]
</IfModule>
HT
    cat > "$APP/.htaccess" <<'HT'
# COHERS-APP — written by deploy/hostinger/setup.sh.
# Application code, .env, storage (report photos) and vendor must never be downloadable.
# public/ has its own .htaccess and is the only folder served.
Options -Indexes
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^ - [F]
</IfModule>
<FilesMatch "^\.|\.(env|sqlite|log|sh|md|json|lock|xml|yml|yaml|bak)$">
    <IfModule mod_authz_core.c>
        Require all denied
    </IfModule>
    <IfModule !mod_authz_core.c>
        Order allow,deny
        Deny from all
    </IfModule>
</FilesMatch>
HT
    # A copy of layout A left over from an earlier run would be served instead: remove our own marker files only.
    rm -f "$DOCROOT/.cohers-public"
    echo "$DOCROOT" > "$APP/.docroot"
    say "Website folder ready: $DOCROOT → $REL/public (the rest of $REL/ is blocked)"
    INSIDE=1
else
    # ---- layout A: app beside the website folder ----
    if [[ ! -f "$DOCROOT/.cohers-public" ]] && [[ -n "$(ls -A "$DOCROOT" 2>/dev/null | grep -vxE 'default\.php(\.disabled)?|index\.html|\.htaccess|cgi-bin')" ]]; then
        old="$DOCROOT.old-$(date +%Y%m%d-%H%M%S)"
        ask MOVE "$DOCROOT already has a website in it. Rename it to $(basename "$old") and put COHERS there? (y/n)" "y"
        [[ "${MOVE,,}" == y* ]] || die "Stopped; nothing changed in $DOCROOT."
        mv "$DOCROOT" "$old"; warn "Old website kept as $old"
        mkdir -p "$DOCROOT"
    fi
    cp -R "$APP/public/." "$DOCROOT/"
    cat > "$DOCROOT/index.php" <<PHP
<?php
// COHERS front controller, written by deploy/hostinger/setup.sh.
// The application lives outside the website folder, in: $APP

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

\$app = '$APP';

if (file_exists(\$maintenance = \$app.'/storage/framework/maintenance.php')) {
    require \$maintenance;
}

require \$app.'/vendor/autoload.php';

\$application = require_once \$app.'/bootstrap/app.php';
\$application->usePublicPath(__DIR__);
\$application->handleRequest(Request::capture());
PHP
    echo "COHERS public files. Re-created by deploy/hostinger/setup.sh on every run." > "$DOCROOT/.cohers-public"
    echo "$DOCROOT" > "$APP/.docroot"
    say "Website folder ready: $DOCROOT"
    INSIDE=0
fi

# --- caches, worker restart, Telegram ------------------------------------------------------
artisan optimize:clear >/dev/null
artisan optimize >/dev/null
artisan queue:restart >/dev/null 2>&1 || true

if artisan tinker --execute='echo app(App\Services\Telegram\TelegramClient::class)->configured() ? "BOT-YES" : "BOT-NO";' 2>/dev/null | grep -q BOT-YES; then
    artisan cohers:telegram-webhook || warn "Webhook not set (does https://$DOMAIN open yet?). Later: Admin → Configuration → Set webhook."
    artisan cohers:telegram-menu-button || true
else
    warn "No Telegram bot token yet: add it in Admin → Configuration, then press Set webhook there."
fi

echo
say "Done: https://$DOMAIN"
echo
echo "Cron job (hPanel → Advanced → Cron Jobs → Custom, every minute: * * * * *), command:"
echo
echo "    $PHP $APP/artisan schedule:run >> /dev/null 2>&1"
echo
echo "One cron job runs both the overdue checks and the queue worker."
echo "If passwords were printed above, copy them now: they are not shown again."
