<?php

/*
 * Sets values in a .env file without breaking quoting (passwords may contain any character).
 * Used by setup.sh.
 *
 *   php write-env.php /path/.env KEY=value [KEY=value …]
 *   php write-env.php --if-empty /path/.env TELEGRAM_WEBHOOK_SECRET=@random
 *
 * --if-empty   only fill keys that are missing or blank
 * @random      a new random 48-character hex secret
 */

$args = array_slice($argv, 1);
$ifEmpty = false;
if (($args[0] ?? '') === '--if-empty') {
    $ifEmpty = true;
    array_shift($args);
}
$file = array_shift($args) ?? '.env';
$env = @file_get_contents($file);
if ($env === false) {
    fwrite(STDERR, "Cannot read {$file}\n");
    exit(1);
}

$quote = function (string $v): string {
    if (preg_match('~^[A-Za-z0-9_.:/@+-]*$~', $v)) {
        return $v;
    }
    // phpdotenv: inside double quotes, \\ \" and \$ are escapes and ${…} would be expanded.
    return '"'.strtr($v, ['\\' => '\\\\', '"' => '\\"', '$' => '\\$']).'"';
};

foreach ($args as $pair) {
    [$key, $value] = array_pad(explode('=', $pair, 2), 2, '');
    if (! preg_match('/^[A-Z][A-Z0-9_]*$/', $key)) {
        fwrite(STDERR, "Bad key: {$key}\n");
        exit(1);
    }
    $pattern = '/^'.$key.'=(.*)$/m';
    $has = preg_match($pattern, $env, $m);
    if ($ifEmpty && $has && trim($m[1], " \t\"'") !== '') {
        continue;
    }
    if ($value === '@random') {
        $value = bin2hex(random_bytes(24));
    }
    $line = $key.'='.$quote($value);
    $env = $has ? preg_replace_callback($pattern, fn () => $line, $env, 1) : rtrim($env)."\n".$line."\n";
}

file_put_contents($file, $env);
