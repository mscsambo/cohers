# Deploying COHERS to Hostinger (hPanel web / cloud hosting)

Shared hosting cannot keep programs running in the background, so on Hostinger COHERS works like this:

- **Telegram → webhook.** Telegram calls `https://YOUR-DOMAIN/api/telegram/webhook` and the bot answers inside that
  request (`TELEGRAM_UPDATE_PROCESSING=after_response`). No polling.
- **One cron job, every minute** runs `artisan schedule:run`. That runs the overdue checks and then the queue worker for
  about 55 seconds (`COHERS_QUEUE_VIA_SCHEDULER=true`), which sends alerts, runs AI triage and downloads photos.
- **MySQL/MariaDB** from hPanel.

The installer supports two layouts and picks one from where you extracted the app. `u123456789` is your hosting
username, and the *website folder* is the folder hPanel serves for your domain or subdomain.

**Layout 1: app inside the website folder** (simplest with a subdomain):

```
WEBSITE-FOLDER/             e.g. public_html/  or  public_html/cohers/  (subdomain)
├── .htaccess               ← written by setup: sends every request to app/public
└── app/                    ← the whole app; its .htaccess refuses every request (.env, storage, vendor…)
    ├── app/ bootstrap/ config/ database/ lang/ resources/ routes/ storage/ vendor/  .env
    └── public/             ← the only part visitors reach: index.php, .htaccess, icons, js/, sw.js
```

Visitors use `https://YOUR-SUBDOMAIN/login`. They never see `/app/public` in the address, and any address under
`/app/…` answers **403 Forbidden**.

**Layout 2: app beside the website folder** (safest: no app files in the website folder at all):

```
/home/u123456789/domains/YOUR-DOMAIN/
├── cohers/          ← the app
└── public_html/     ← setup copies the public files here; index.php points at ../cohers
```

On a VPS bought through hPanel you have root access, so use `DEPLOY.md` (nginx + supervisor) instead.

---

## Step 0 — In hPanel, before uploading

1. **Domain or subdomain** for COHERS (e.g. `cohers.example.org`) is added to the hosting plan and **SSL is active**
   (hPanel → Security → SSL). Telegram only works with `https://`.
2. **PHP 8.3**: hPanel → Advanced → PHP Configuration → PHP 8.3 (8.2 is the minimum).
3. **Database**: hPanel → Databases → Management → create one. Write down the database name, user and password
   (they look like `u123456789_cohers`).
4. **Telegram**: use a bot token that nothing else is polling. Stop `telegram-poll` on your PC, or create a separate
   test bot for your PC.
5. **SSH**: available on **Premium and higher**. Enable it at Advanced → SSH Access, which also shows the host, port
   (usually 65002) and username. **Single plans have no SSH**: use Step 3B.

## Step 1 — Build the package (on your PC, VS Code terminal in `D:\cohers`)

```powershell
.\deploy\make-hostinger-package.ps1
```

This creates `D:\cohers\deploy\dist\cohers-hostinger.zip` (about 8 MB). It contains the code and production `vendor\`.
It does **not** contain `.env`, the SQLite database, photos, logs or tests.

## Step 2 — Upload

The zip extracts to a folder named `cohers/`. Below, **APP-FOLDER** means wherever that folder ends up.

- **Layout 1 (subdomain, app inside):** File Manager → open the subdomain's website folder (hPanel → Domains →
  Subdomains shows it, e.g. `public_html/cohers`) → Upload `cohers-hostinger.zip` → right-click → **Extract** →
  rename the new `cohers` folder to **`app`**. APP-FOLDER is `…/YOUR-SUBDOMAIN-FOLDER/app`.
- **Layout 2 (beside):** File Manager → open `domains/YOUR-DOMAIN/` (the folder that **contains** `public_html`) →
  Upload → **Extract**. APP-FOLDER is `domains/YOUR-DOMAIN/cohers`.

Delete the zip afterwards. The installer finds the website folder by itself: for layout 1 it's the folder holding
`app/`; for layout 2 it's the `public_html` beside `cohers/`. Over SSH it asks you to confirm. In Step 3B you can force it
by putting `DOCROOT=/full/path ` before `bash`.

## Step 3A — Install over SSH (Premium plan and up)

```bash
ssh -p 65002 u123456789@YOUR-SERVER-IP
bash ~/APP-FOLDER/deploy/hostinger/setup.sh
# e.g. bash ~/domains/example.org/public_html/cohers/app/deploy/hostinger/setup.sh
```

It asks for the domain, database details, your admin e-mail, demo data (y/n), the bot token and the Gemini key. Press
Enter to accept the value in brackets. Then it:

- writes `APP-FOLDER/.env` with a new `APP_KEY` and webhook secret;
- creates the tables and your administrator account, **printing the password once — copy it**;
- sets up the website folder:
  - **Layout 1:** writes the two `.htaccess` files. An existing `.htaccess` there is saved as `.htaccess.before-cohers-DATE`.
  - **Layout 2:** copies the public files. A website already in `public_html` is renamed `public_html.old-DATE`.
  - Either way, Hostinger's `default.php` is renamed `default.php.disabled`. Nothing is deleted;
- sets the Telegram webhook and the Mini App menu button (when a token was given);
- prints the cron command for Step 4.

## Step 3B — Install without SSH (Single plan)

1. File Manager → `APP-FOLDER/deploy/hostinger/.env.hostinger` → **Copy** to `APP-FOLDER/.env`. Open that `.env` and set:
   - `APP_URL=https://YOUR-DOMAIN`
   - `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` from Step 0 (put the password in double quotes if it has spaces or `#`)
   - `SETUP_ADMIN_EMAIL=you@example.org`, and `SETUP_DEMO=y` if you want demo data
   - leave `APP_KEY` and `TELEGRAM_WEBHOOK_SECRET` empty: they are generated.
2. hPanel → Advanced → Cron Jobs → Custom → every minute → command (one line):
   ```
   bash /home/u123456789/APP-FOLDER/deploy/hostinger/setup.sh --yes > /home/u123456789/APP-FOLDER/storage/logs/setup.txt 2>&1
   ```
   Example for layout 1: `bash /home/u123456789/domains/example.org/public_html/cohers/app/deploy/hostinger/setup.sh --yes > /home/u123456789/domains/example.org/public_html/cohers/app/storage/logs/setup.txt 2>&1`
3. Wait 2 minutes, then open `APP-FOLDER/storage/logs/setup.txt` in File Manager. It should end with `Done`. **Copy the
   password**, then **delete this cron job and `setup.txt`**.

   If it says `ERROR`, fix what it names (usually a `DB_*` value or the PHP version) and wait for the next minute.

## Step 4 — The cron job (both ways, keep it forever)

hPanel → Advanced → Cron Jobs → Custom → every minute (`* * * * *`):

```
/usr/bin/php /home/u123456789/APP-FOLDER/artisan schedule:run >> /dev/null 2>&1
```

Use the exact line setup.sh printed (it has the right PHP path). One job is enough.

## Step 5 — Check it works

1. Open `https://YOUR-DOMAIN`, sign in with your e-mail and the printed password, then set up two-factor authentication.
2. **Admin → Configuration**:
   - Telegram: enter the bot token if you didn't before, **Save**, then **Set webhook**, then **Test connection**.
     The webhook should be `https://YOUR-DOMAIN/api/telegram/webhook` with no error.
   - Gemini: **Run test call** if you use it.
3. **My Telegram** (top bar): connect your own Telegram account.
4. From a phone, send `/start` to the bot and submit a test report. It should appear under **Reports** within a minute.
5. **Admin → Alerts & Jobs**: messages should show *Sent*. If they stay *Pending*, the cron job is not running.
6. **Layout 1 only, important:** open `https://YOUR-SUBDOMAIN/app/.env` and `https://YOUR-SUBDOMAIN/app/composer.json`.
   Both must show **403 Forbidden**. If either downloads or displays a file, the `.htaccess` protection is not working:
   take the site offline (rename `app/.env`) and switch to layout 2.

## Updating later

1. Build a new zip (Step 1).
2. Upload it to the same place as before → **Extract**. It creates a folder named `cohers`, so for layout 1 extract
   it **next to** `app/` and copy the contents of the new `cohers/` into `app/`, allowing overwrite (or use SSH:
   `cp -R cohers/. app/ && rm -rf cohers`). Your `.env`, database and photos are kept.
3. Either run `bash ~/APP-FOLDER/deploy/hostinger/setup.sh` over SSH, or add the Step 3B one-time cron
   again. It runs the new migrations, refreshes the website folder and clears the caches.

## Backups

- hPanel makes hosting backups, but also keep your own copy of:
  - **`APP-FOLDER/.env`**: its `APP_KEY` is needed to read the two-factor secrets and the keys saved in Admin → Configuration;
  - the database (hPanel → Databases → phpMyAdmin → Export);
  - `APP-FOLDER/storage/app/private/` (report photos).
- Always restore the database together with the `.env` it was used with.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Hostinger page still shows / "Index of" | `public_html/default.php` or `index.html` is still there. Rename it, or re-run setup. |
| Error 500 | Read `APP-FOLDER/storage/logs/laravel-DATE.log`. Re-run setup after any `.env` change (it clears the config cache). |
| "Cannot connect to the database" | `DB_*` in `APP-FOLDER/.env` must match hPanel → Databases. Host `127.0.0.1` (try `localhost` if that fails). |
| Bot does not answer | Admin → Configuration → Test connection: the webhook must be your https address with no error. Make sure nothing else polls the same token. |
| Alerts stay *Pending* | The cron job isn't running or has the wrong path: compare it with the line setup.sh printed. |
| setup says PHP is too old | The SSH/cron PHP follows hPanel → PHP Configuration. Set 8.3 and run again. |
| Links come out as `http://` | You turned on Hostinger CDN or another proxy: add `TRUSTED_PROXIES=REMOTE_ADDR` to `.env`, then re-run setup. |
| Forgot the admin password | SSH: `php ~/APP-FOLDER/artisan cohers:create-admin you@example.org` (prints a new one). |
| Layout 1: 403 on every page | The website folder's `.htaccess` is missing or was replaced. Re-run setup (it rewrites it). |
| Restored DB with another `.env` | See *Troubleshooting* in `DEPLOY-PTERODACTYL.md` (`COHERS_RESET_MFA`). |

## Notes

- Shared plans cap CPU, memory and PHP processes. That is fine for a pilot. For a district-wide rollout, a VPS with
  `DEPLOY.md` is more robust.
- The dashboard loads Tailwind, Chart.js and the Telegram script from public CDNs, so visitors need internet access
  (true for Telegram anyway).
- Data on your PC (SQLite, test reports, photos) is not copied; the server starts fresh.
