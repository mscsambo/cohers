<?php

use App\Jobs\CheckOverdueAssignmentsJob;
use Illuminate\Support\Facades\Schedule;

// Due-time checks and fallback routing (section 12). Server timestamps (UTC).
Schedule::job(new CheckOverdueAssignmentsJob)->everyMinute()->withoutOverlapping();

Schedule::command('queue:prune-failed --hours=720')->daily();

// Shared hosting (no supervisor): the one-minute cron runs the queue worker for up to
// 55 seconds, so notifications, AI triage and photo downloads go out within seconds.
// Defined last because schedule:run waits for it. The lock stops a second worker if a
// minute overruns; it expires after 10 minutes if a worker is ever killed.
if (config('cohers.queue_via_scheduler')) {
    Schedule::command('queue:work --max-time=55 --sleep=2 --tries=5 --backoff=10 --timeout=50 --memory=256')
        ->name('cohers-queue-worker')
        ->everyMinute()
        ->withoutOverlapping(10);
}
